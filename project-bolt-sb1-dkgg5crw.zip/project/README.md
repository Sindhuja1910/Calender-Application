# Communication Calendar

A comprehensive calendar application for tracking and managing company communications.

## Features

- **Admin Module**
  - Company management (add, edit, delete)
  - Communication method configuration
  - Periodicity settings

- **Dashboard**
  - Overview of company communications
  - Last 5 communications per company
  - Next scheduled communications
  - Quick actions

- **Calendar View**
  - Monthly view of all communications
  - Color-coded status indicators
  - Communication logging

- **Reports & Analytics**
  - Communication method usage stats
  - Company engagement metrics
  - Overdue communications tracking

## Tech Stack

- React with TypeScript
- Tailwind CSS for styling
- Zustand for state management
- date-fns for date handling
- Lucide React for icons
- React Router for navigation

## Getting Started

1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   ```
3. Start the development server:
   ```bash
   npm run dev
   ```

## Project Structure

```
src/
├── components/         # Reusable UI components
├── pages/             # Page components
├── store/             # Zustand store
├── types/             # TypeScript types
└── utils/             # Utility functions
```

## Usage

### Adding a Company

1. Navigate to the Admin Panel
2. Click "Add Company"
3. Fill in the company details
4. Click "Add Company" to save

### Logging Communications

1. Find the company on the Dashboard
2. Click "Log Communication"
3. Select the communication method
4. Add date and notes
5. Submit the form

### Viewing Reports

Navigate to the Reports section to view:
- Communication method statistics
- Company engagement metrics
- Overdue communications

## License

MIT