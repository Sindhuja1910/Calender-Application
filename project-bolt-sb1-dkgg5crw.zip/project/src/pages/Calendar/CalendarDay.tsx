import React from 'react';
import { format, isToday } from 'date-fns';
import { Communication, Company } from '../../types';
import { Mail, MessageSquare, Phone } from 'lucide-react';

interface CalendarDayProps {
  date: Date;
  communications: Communication[];
  companies: Company[];
}

const CalendarDay: React.FC<CalendarDayProps> = ({
  date,
  communications,
  companies,
}) => {
  const getCommunicationIcon = (methodId: string) => {
    switch (methodId) {
      case '1':
      case '2':
        return <MessageSquare className="w-4 h-4" />;
      case '3':
        return <Mail className="w-4 h-4" />;
      case '4':
        return <Phone className="w-4 h-4" />;
      default:
        return null;
    }
  };

  const getCompanyName = (companyId: string) => {
    return companies.find((c) => c.id === companyId)?.name || '';
  };

  return (
    <div
      className={`min-h-[120px] bg-white p-2 ${
        isToday(date) ? 'bg-blue-50' : ''
      }`}
    >
      <div
        className={`text-sm ${
          isToday(date)
            ? 'font-bold text-blue-600'
            : 'font-medium text-gray-500'
        }`}
      >
        {format(date, 'd')}
      </div>
      <div className="mt-2 space-y-1">
        {communications.map((comm) => (
          <div
            key={comm.id}
            className="flex items-center space-x-1 text-xs bg-gray-100 rounded p-1"
            title={comm.notes}
          >
            {getCommunicationIcon(comm.methodId)}
            <span className="truncate">{getCompanyName(comm.companyId)}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CalendarDay;