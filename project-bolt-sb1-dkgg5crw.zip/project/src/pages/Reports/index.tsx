import React from 'react';
import { useStore } from '../../store/useStore';
import CommunicationStats from './CommunicationStats';
import CompanyEngagement from './CompanyEngagement';
import OverdueReport from './OverdueReport';

const Reports = () => {
  return (
    <div className="space-y-8">
      <h1 className="text-2xl font-bold text-gray-900">Reports & Analytics</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <CommunicationStats />
        <CompanyEngagement />
        <OverdueReport />
      </div>
    </div>
  );
};

export default Reports;