import React from 'react';
import { useStore } from '../../store/useStore';
import { Users } from 'lucide-react';

const CompanyEngagement = () => {
  const { companies, communications } = useStore();

  const companyStats = companies.map((company) => ({
    ...company,
    communicationCount: communications.filter((c) => c.companyId === company.id)
      .length,
  }));

  const sortedCompanies = [...companyStats].sort(
    (a, b) => b.communicationCount - a.communicationCount
  );

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center space-x-2 mb-6">
        <Users className="w-5 h-5 text-indigo-600" />
        <h2 className="text-xl font-semibold text-gray-900">
          Company Engagement
        </h2>
      </div>

      <div className="space-y-4">
        {sortedCompanies.map((company) => (
          <div
            key={company.id}
            className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
          >
            <div>
              <h3 className="font-medium text-gray-900">{company.name}</h3>
              <p className="text-sm text-gray-500">{company.location}</p>
            </div>
            <div className="text-right">
              <p className="text-2xl font-bold text-indigo-600">
                {company.communicationCount}
              </p>
              <p className="text-xs text-gray-500">communications</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CompanyEngagement;