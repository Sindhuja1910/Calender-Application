import React from 'react';
import { useStore } from '../../store/useStore';
import { AlertCircle } from 'lucide-react';
import { differenceInDays } from 'date-fns';

const OverdueReport = () => {
  const { companies, communications } = useStore();

  const overdueCompanies = companies.map((company) => {
    const lastCommunication = communications
      .filter((c) => c.companyId === company.id)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())[0];

    const daysSinceLastComm = lastCommunication
      ? differenceInDays(new Date(), new Date(lastCommunication.date))
      : Infinity;

    return {
      ...company,
      daysOverdue: Math.max(
        0,
        daysSinceLastComm - company.communicationPeriodicity
      ),
    };
  });

  const sortedOverdue = overdueCompanies
    .filter((c) => c.daysOverdue > 0)
    .sort((a, b) => b.daysOverdue - a.daysOverdue);

  return (
    <div className="bg-white rounded-lg shadow-md p-6 col-span-full">
      <div className="flex items-center space-x-2 mb-6">
        <AlertCircle className="w-5 h-5 text-red-600" />
        <h2 className="text-xl font-semibold text-gray-900">Overdue Communications</h2>
      </div>

      {sortedOverdue.length > 0 ? (
        <div className="space-y-4">
          {sortedOverdue.map((company) => (
            <div
              key={company.id}
              className="flex items-center justify-between p-4 bg-red-50 rounded-lg"
            >
              <div>
                <h3 className="font-medium text-gray-900">{company.name}</h3>
                <p className="text-sm text-gray-500">{company.location}</p>
              </div>
              <div className="text-right">
                <p className="text-lg font-bold text-red-600">
                  {company.daysOverdue} days
                </p>
                <p className="text-xs text-gray-500">overdue</p>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <p className="text-center text-gray-500">No overdue communications!</p>
      )}
    </div>
  );
};

export default OverdueReport;