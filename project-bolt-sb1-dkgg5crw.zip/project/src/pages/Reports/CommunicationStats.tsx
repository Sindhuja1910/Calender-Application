import React from 'react';
import { useStore } from '../../store/useStore';
import { BarChart2 } from 'lucide-react';

const CommunicationStats = () => {
  const { communications, communicationMethods } = useStore();

  const stats = communicationMethods.map((method) => ({
    ...method,
    count: communications.filter((c) => c.methodId === method.id).length,
  }));

  const maxCount = Math.max(...stats.map((s) => s.count));

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center space-x-2 mb-6">
        <BarChart2 className="w-5 h-5 text-indigo-600" />
        <h2 className="text-xl font-semibold text-gray-900">
          Communication Methods Usage
        </h2>
      </div>

      <div className="space-y-4">
        {stats.map((stat) => (
          <div key={stat.id}>
            <div className="flex justify-between text-sm text-gray-600 mb-1">
              <span>{stat.name}</span>
              <span>{stat.count}</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-indigo-600 h-2 rounded-full"
                style={{
                  width: `${(stat.count / maxCount) * 100}%`,
                }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CommunicationStats;