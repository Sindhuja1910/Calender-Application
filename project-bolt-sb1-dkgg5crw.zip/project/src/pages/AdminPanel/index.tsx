import React from 'react';
import CompanyList from './CompanyList';
import CommunicationMethodList from './CommunicationMethodList';

const AdminPanel = () => {
  return (
    <div className="space-y-8">
      <h1 className="text-2xl font-bold text-gray-900">Admin Panel</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <CompanyList />
        <CommunicationMethodList />
      </div>
    </div>
  );
};

export default AdminPanel;