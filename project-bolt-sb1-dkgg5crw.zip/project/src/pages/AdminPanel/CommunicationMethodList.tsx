import React from 'react';
import { useStore } from '../../store/useStore';
import { MessageSquare } from 'lucide-react';

const CommunicationMethodList = () => {
  const { communicationMethods } = useStore();

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-xl font-semibold text-gray-900 mb-6">
        Communication Methods
      </h2>

      <div className="space-y-4">
        {communicationMethods.map((method) => (
          <div
            key={method.id}
            className="border rounded-lg p-4 hover:bg-gray-50"
          >
            <div className="flex items-start space-x-3">
              <MessageSquare className="w-5 h-5 text-gray-400 mt-1" />
              <div>
                <h3 className="font-medium text-gray-900">
                  {method.name}
                  {method.isMandatory && (
                    <span className="ml-2 text-xs bg-red-100 text-red-800 px-2 py-0.5 rounded-full">
                      Required
                    </span>
                  )}
                </h3>
                <p className="text-sm text-gray-500">{method.description}</p>
                <p className="text-xs text-gray-400 mt-1">
                  Sequence: {method.sequence}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CommunicationMethodList;