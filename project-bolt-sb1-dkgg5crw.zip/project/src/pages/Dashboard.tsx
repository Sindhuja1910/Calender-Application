import React, { useState } from 'react';
import { CompanyStatusCard } from '../components/dashboard/CompanyStatusCard';
import { RecentActivity } from '../components/dashboard/RecentActivity';
import { Card, CardContent } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Plus } from 'lucide-react';
import CompanyList from '../components/CompanyList';
import CompanyForm from '../components/CompanyForm';

const Dashboard = () => {
  const [isFormOpen, setIsFormOpen] = useState(false);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
        <Button 
          icon={<Plus className="w-4 h-4" />}
          onClick={() => setIsFormOpen(true)}
        >
          Add Company
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <CompanyStatusCard />
        <RecentActivity />
      </div>

      <Card>
        <CardContent>
          <CompanyList />
        </CardContent>
      </Card>

      {isFormOpen && (
        <CompanyForm
          onClose={() => setIsFormOpen(false)}
        />
      )}
    </div>
  );
};

export default Dashboard;