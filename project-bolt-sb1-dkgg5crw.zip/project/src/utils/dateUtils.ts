import { differenceInDays, isAfter, isBefore, isToday } from 'date-fns';
import { Communication } from '../types';

export const getCommunicationStatus = (
  lastCommunication: Communication | undefined,
  periodicity: number
) => {
  if (!lastCommunication) {
    return 'overdue';
  }

  const lastCommDate = new Date(lastCommunication.date);
  const today = new Date();
  const nextDueDate = new Date(lastCommDate);
  nextDueDate.setDate(nextDueDate.getDate() + periodicity);

  if (isAfter(today, nextDueDate)) {
    return 'overdue';
  }

  if (isToday(nextDueDate)) {
    return 'due';
  }

  return 'upcoming';
};

export const getDaysUntilDue = (
  lastCommunication: Communication | undefined,
  periodicity: number
) => {
  if (!lastCommunication) {
    return -periodicity;
  }

  const lastCommDate = new Date(lastCommunication.date);
  const today = new Date();
  const nextDueDate = new Date(lastCommDate);
  nextDueDate.setDate(nextDueDate.getDate() + periodicity);

  return differenceInDays(nextDueDate, today);
};