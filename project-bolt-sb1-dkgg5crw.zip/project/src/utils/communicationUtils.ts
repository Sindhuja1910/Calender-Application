import { Communication, Company } from '../types';

export const getLastCommunication = (
  communications: Communication[],
  companyId: string
): Communication | undefined => {
  return communications
    .filter((comm) => comm.companyId === companyId)
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())[0];
};

export const getNextScheduledCommunication = (
  company: Company,
  lastComm: Communication | undefined
): Date | null => {
  if (!lastComm) {
    return new Date();
  }

  const nextDate = new Date(lastComm.date);
  nextDate.setDate(nextDate.getDate() + company.communicationPeriodicity);
  return nextDate;
};