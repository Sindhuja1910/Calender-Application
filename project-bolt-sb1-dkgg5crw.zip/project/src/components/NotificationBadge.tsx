import React from 'react';
import { useStore } from '../store/useStore';
import { getCommunicationStatus } from '../utils/dateUtils';
import { getLastCommunication } from '../utils/communicationUtils';

const NotificationBadge = () => {
  const { companies, communications } = useStore();
  
  const overdueCount = companies.filter((company) => {
    const lastComm = getLastCommunication(communications, company.id);
    return getCommunicationStatus(lastComm, company.communicationPeriodicity) === 'overdue';
  }).length;

  const dueCount = companies.filter((company) => {
    const lastComm = getLastCommunication(communications, company.id);
    return getCommunicationStatus(lastComm, company.communicationPeriodicity) === 'due';
  }).length;

  const totalCount = overdueCount + dueCount;

  if (totalCount === 0) return null;

  return (
    <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
      {totalCount}
    </span>
  );
};

export default NotificationBadge;