import React from 'react';
import { Card, CardHeader, CardContent } from '../ui/Card';
import { Badge } from '../ui/Badge';
import { Building2, Users } from 'lucide-react';
import { useStore } from '../../store/useStore';
import { getCommunicationStatus } from '../../utils/dateUtils';
import { getLastCommunication } from '../../utils/communicationUtils';

export const CompanyStatusCard = () => {
  const { companies, communications } = useStore();

  const stats = companies.reduce((acc, company) => {
    const lastComm = getLastCommunication(communications, company.id);
    const status = getCommunicationStatus(lastComm, company.communicationPeriodicity);
    acc[status] = (acc[status] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-gray-900">Company Status</h3>
          <Building2 className="w-5 h-5 text-gray-400" />
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-3 gap-4">
          <div className="text-center">
            <Badge variant="error">{stats.overdue || 0}</Badge>
            <p className="mt-1 text-sm text-gray-600">Overdue</p>
          </div>
          <div className="text-center">
            <Badge variant="warning">{stats.due || 0}</Badge>
            <p className="mt-1 text-sm text-gray-600">Due Today</p>
          </div>
          <div className="text-center">
            <Badge variant="success">{stats.upcoming || 0}</Badge>
            <p className="mt-1 text-sm text-gray-600">On Track</p>
          </div>
        </div>
        <div className="mt-4 pt-4 border-t">
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-600">Total Companies</span>
            <span className="font-semibold text-gray-900">{companies.length}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};