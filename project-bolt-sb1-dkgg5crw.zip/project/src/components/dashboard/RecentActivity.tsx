import React from 'react';
import { Card, CardHeader, CardContent } from '../ui/Card';
import { Activity } from 'lucide-react';
import { useStore } from '../../store/useStore';
import { format } from 'date-fns';

export const RecentActivity = () => {
  const { communications, companies, communicationMethods } = useStore();

  const recentComms = [...communications]
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 5)
    .map(comm => ({
      ...comm,
      company: companies.find(c => c.id === comm.companyId),
      method: communicationMethods.find(m => m.id === comm.methodId),
    }));

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-gray-900">Recent Activity</h3>
          <Activity className="w-5 h-5 text-gray-400" />
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {recentComms.map(comm => (
            <div key={comm.id} className="flex items-start space-x-3">
              <div className="flex-shrink-0 w-2 h-2 mt-2 rounded-full bg-indigo-500" />
              <div>
                <p className="text-sm font-medium text-gray-900">
                  {comm.company?.name}
                </p>
                <div className="flex items-center space-x-2 text-xs text-gray-500">
                  <span>{comm.method?.name}</span>
                  <span>•</span>
                  <span>{format(new Date(comm.date), 'MMM d, yyyy')}</span>
                </div>
                {comm.notes && (
                  <p className="mt-1 text-sm text-gray-600">{comm.notes}</p>
                )}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};