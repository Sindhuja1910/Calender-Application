import React, { useState } from 'react';
import { useStore } from '../store/useStore';
import { Company } from '../types';
import { Building2, Pencil, Trash2 } from 'lucide-react';
import { Button } from './ui/Button';
import CompanyForm from './CompanyForm';
import { Badge } from './ui/Badge';
import { getCommunicationStatus } from '../utils/dateUtils';
import { getLastCommunication } from '../utils/communicationUtils';

const CompanyList = () => {
  const { companies, communications, deleteCompany } = useStore();
  const [editingCompany, setEditingCompany] = useState<Company | null>(null);
  const [isFormOpen, setIsFormOpen] = useState(false);

  const getStatusBadge = (company: Company) => {
    const lastComm = getLastCommunication(communications, company.id);
    const status = getCommunicationStatus(lastComm, company.communicationPeriodicity);
    
    const variants = {
      overdue: 'error',
      due: 'warning',
      upcoming: 'success',
    } as const;

    return (
      <Badge variant={variants[status]}>
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </Badge>
    );
  };

  return (
    <div className="space-y-4">
      <div className="divide-y divide-gray-200">
        {companies.map((company) => (
          <div key={company.id} className="py-4 first:pt-0 last:pb-0">
            <div className="flex justify-between items-start">
              <div className="flex items-center space-x-3">
                <Building2 className="w-5 h-5 text-gray-400" />
                <div>
                  <h3 className="font-medium text-gray-900">{company.name}</h3>
                  <p className="text-sm text-gray-500">{company.location}</p>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                {getStatusBadge(company)}
                <div className="flex space-x-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      setEditingCompany(company);
                      setIsFormOpen(true);
                    }}
                    icon={<Pencil className="w-4 h-4" />}
                  >
                    Edit
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => deleteCompany(company.id)}
                    icon={<Trash2 className="w-4 h-4" />}
                    className="text-red-600 hover:text-red-700 hover:bg-red-50"
                  >
                    Delete
                  </Button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {isFormOpen && (
        <CompanyForm
          company={editingCompany}
          onClose={() => {
            setIsFormOpen(false);
            setEditingCompany(null);
          }}
        />
      )}
    </div>
  );
};

export default CompanyList;