import React from 'react';
import { useStore } from '../store/useStore';
import { getCommunicationStatus } from '../utils/dateUtils';
import { getLastCommunication } from '../utils/communicationUtils';
import { AlertCircle, Clock } from 'lucide-react';

const Notifications = () => {
  const { companies, communications } = useStore();

  const overdueCompanies = companies.filter((company) => {
    const lastComm = getLastCommunication(communications, company.id);
    return getCommunicationStatus(lastComm, company.communicationPeriodicity) === 'overdue';
  });

  const dueCompanies = companies.filter((company) => {
    const lastComm = getLastCommunication(communications, company.id);
    return getCommunicationStatus(lastComm, company.communicationPeriodicity) === 'due';
  });

  if (overdueCompanies.length === 0 && dueCompanies.length === 0) {
    return null;
  }

  return (
    <div className="fixed bottom-4 right-4 space-y-2">
      {overdueCompanies.length > 0 && (
        <div className="bg-red-100 border-l-4 border-red-500 p-4 rounded-lg shadow-lg">
          <div className="flex items-center">
            <AlertCircle className="w-5 h-5 text-red-500 mr-2" />
            <div>
              <p className="font-medium text-red-700">
                {overdueCompanies.length} overdue communications
              </p>
              <p className="text-sm text-red-600">
                Action required for {overdueCompanies.map(c => c.name).join(', ')}
              </p>
            </div>
          </div>
        </div>
      )}

      {dueCompanies.length > 0 && (
        <div className="bg-yellow-100 border-l-4 border-yellow-500 p-4 rounded-lg shadow-lg">
          <div className="flex items-center">
            <Clock className="w-5 h-5 text-yellow-500 mr-2" />
            <div>
              <p className="font-medium text-yellow-700">
                {dueCompanies.length} communications due today
              </p>
              <p className="text-sm text-yellow-600">
                Remember to contact {dueCompanies.map(c => c.name).join(', ')}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Notifications;