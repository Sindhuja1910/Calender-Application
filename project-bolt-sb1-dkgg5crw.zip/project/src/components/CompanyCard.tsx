import React, { useState } from 'react';
import { Company, Communication } from '../types';
import { format } from 'date-fns';
import { Building2, Calendar, Mail, Phone, MessageSquare } from 'lucide-react';
import { getCommunicationStatus } from '../utils/dateUtils';
import { getLastCommunication } from '../utils/communicationUtils';
import CommunicationModal from './CommunicationModal';

interface CompanyCardProps {
  company: Company;
  communications: Communication[];
}

const CompanyCard: React.FC<CompanyCardProps> = ({ company, communications }) => {
  const [showModal, setShowModal] = useState(false);
  const lastComm = getLastCommunication(communications, company.id);
  const status = getCommunicationStatus(lastComm, company.communicationPeriodicity);

  const statusColors = {
    overdue: 'bg-red-100 text-red-800',
    due: 'bg-yellow-100 text-yellow-800',
    upcoming: 'bg-green-100 text-green-800',
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-start justify-between">
        <div className="flex items-center space-x-3">
          <Building2 className="w-6 h-6 text-gray-400" />
          <div>
            <h3 className="text-lg font-medium text-gray-900">{company.name}</h3>
            <p className="text-sm text-gray-500">{company.location}</p>
          </div>
        </div>
        <span className={`px-2 py-1 rounded-full text-xs ${statusColors[status]}`}>
          {status.charAt(0).toUpperCase() + status.slice(1)}
        </span>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-4">
        <div className="flex items-center space-x-2">
          <Mail className="w-4 h-4 text-gray-400" />
          <span className="text-sm text-gray-600">{company.emails[0]}</span>
        </div>
        <div className="flex items-center space-x-2">
          <Phone className="w-4 h-4 text-gray-400" />
          <span className="text-sm text-gray-600">{company.phoneNumbers[0]}</span>
        </div>
      </div>

      <div className="mt-4">
        <h4 className="text-sm font-medium text-gray-900 mb-2">Last Communication</h4>
        {lastComm ? (
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <MessageSquare className="w-4 h-4" />
            <span>{format(new Date(lastComm.date), 'MMM d, yyyy')}</span>
          </div>
        ) : (
          <p className="text-sm text-gray-500">No communications yet</p>
        )}
      </div>

      <div className="mt-4">
        <button
          onClick={() => setShowModal(true)}
          className="w-full flex items-center justify-center space-x-2 px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700"
        >
          <Calendar className="w-4 h-4" />
          <span>Log Communication</span>
        </button>
      </div>

      {showModal && (
        <CommunicationModal
          companyId={company.id}
          onClose={() => setShowModal(false)}
        />
      )}
    </div>
  );
};

export default CompanyCard;