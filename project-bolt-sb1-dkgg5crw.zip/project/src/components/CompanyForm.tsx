import React, { useState } from 'react';
import { useStore } from '../store/useStore';
import { Company } from '../types';
import { X } from 'lucide-react';
import { Button } from './ui/Button';
import { Card, CardHeader, CardContent, CardFooter } from './ui/Card';

interface CompanyFormProps {
  company?: Company | null;
  onClose: () => void;
}

const CompanyForm: React.FC<CompanyFormProps> = ({ company, onClose }) => {
  const { addCompany, updateCompany } = useStore();
  const [formData, setFormData] = useState({
    name: company?.name || '',
    location: company?.location || '',
    linkedinProfile: company?.linkedinProfile || '',
    emails: company?.emails.join(', ') || '',
    phoneNumbers: company?.phoneNumbers.join(', ') || '',
    comments: company?.comments || '',
    communicationPeriodicity: company?.communicationPeriodicity || 14,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const companyData: Company = {
      id: company?.id || crypto.randomUUID(),
      name: formData.name,
      location: formData.location,
      linkedinProfile: formData.linkedinProfile,
      emails: formData.emails.split(',').map((email) => email.trim()),
      phoneNumbers: formData.phoneNumbers.split(',').map((phone) => phone.trim()),
      comments: formData.comments,
      communicationPeriodicity: Number(formData.communicationPeriodicity),
    };

    if (company) {
      updateCompany(company.id, companyData);
    } else {
      addCompany(companyData);
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <Card className="w-full max-w-2xl">
        <form onSubmit={handleSubmit}>
          <CardHeader>
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">
                {company ? 'Edit Company' : 'Add Company'}
              </h2>
              <Button
                variant="ghost"
                size="sm"
                onClick={onClose}
                icon={<X className="w-5 h-5" />}
              />
            </div>
          </CardHeader>

          <CardContent className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Company Name
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) =>
                  setFormData({ ...formData, name: e.target.value })
                }
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Location
              </label>
              <input
                type="text"
                value={formData.location}
                onChange={(e) =>
                  setFormData({ ...formData, location: e.target.value })
                }
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                LinkedIn Profile
              </label>
              <input
                type="url"
                value={formData.linkedinProfile}
                onChange={(e) =>
                  setFormData({ ...formData, linkedinProfile: e.target.value })
                }
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Email Addresses (comma-separated)
              </label>
              <input
                type="text"
                value={formData.emails}
                onChange={(e) =>
                  setFormData({ ...formData, emails: e.target.value })
                }
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Phone Numbers (comma-separated)
              </label>
              <input
                type="text"
                value={formData.phoneNumbers}
                onChange={(e) =>
                  setFormData({ ...formData, phoneNumbers: e.target.value })
                }
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Communication Periodicity (days)
              </label>
              <input
                type="number"
                min="1"
                value={formData.communicationPeriodicity}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    communicationPeriodicity: parseInt(e.target.value),
                  })
                }
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Comments
              </label>
              <textarea
                value={formData.comments}
                onChange={(e) =>
                  setFormData({ ...formData, comments: e.target.value })
                }
                rows={3}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
              />
            </div>
          </CardContent>

          <CardFooter className="flex justify-end space-x-3">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
            >
              Cancel
            </Button>
            <Button type="submit">
              {company ? 'Update' : 'Add'} Company
            </Button>
          </CardFooter>
        </form>
      </Card>
    </div>
  );
};

export default CompanyForm;